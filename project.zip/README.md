# QuizGen #
#### Video Demo: https://www.youtube.com/watch?v=lvmRy3AyD4I
#### Description:
This is a website that allows you to create custom duolingo style quizzes about any subject, leveraging openapi and built on NextJS. The frontend features various animations with KUTE and Framer Motion, and uses DaisyUI components while the backend is built with the help of Axios.