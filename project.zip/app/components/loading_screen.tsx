import SquareProgress from "./square_progress";

export default function LoadingScreen() {
    return <>
        <SquareProgress></SquareProgress>
    </>;
}